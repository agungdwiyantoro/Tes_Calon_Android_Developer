package com.example.tes_calon_android_developer;

public class model {
    String title, description, category, image;
    int count;
    float prize, rate;

    public model(String title, String description, String category, String image, int count, float prize, float rate) {
        this.title = title;
        this.description = description;
        this.category = category;
        this.image = image;
        this.count = count;
        this.prize = prize;
        this.rate = rate;
    }
}
