package com.example.tes_calon_android_developer;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    //ArrayList<model> datalList = new ArrayList<model>();
    //RecycleView ReView;
    String[]URLs = {"https://fakestoreapi.com/products",
            "https://fakestoreapi.com/products",
            "https://fakestoreapi.com/products"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        parseApiData();
    }

    public void parseApiData(){
      //  Adapter adapter = new Adapater(dataList, this);
        StringRequest stringRequest = new StringRequest(Request.Method.GET, URLs[0], new Response.Listener<String>() {

            @Override
            public void onResponse(String response) {
                Log.e("Res : ", response);
                JSONObject ob  = new JSONObject(JS)

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }
}